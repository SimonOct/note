#!/bin/bash
#
#********************************************************************
#Author:		wangxiaochun
#QQ: 			29308620
#Date: 			2021-03-09
#FileName：		push_ssh_key.sh
#URL: 			http://www.wangxiaochun.com
#Description：		The test script
#Copyright (C): 	2021 All rights reserved
#********************************************************************

IPLIST="
10.0.0.101
10.0.0.102
10.0.0.103"

rpm -q sshpass &> /dev/null || yum -y install sshpass  

[ -f /root/.ssh/id_rsa ] || ssh-keygen -f /root/.ssh/id_rsa  -P ''

export SSHPASS=123456

for IP in $IPLIST;do
    {
    sshpass -e ssh-copy-id -o StrictHostKeyChecking=no $IP 
    }&
done 
wait

