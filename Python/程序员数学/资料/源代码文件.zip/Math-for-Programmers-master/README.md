# Math-for-Programmers
Source code for the book, Math for Programmers

Up-to-date on GitHub at https://github.com/orlandpm/Math-for-Programmers
